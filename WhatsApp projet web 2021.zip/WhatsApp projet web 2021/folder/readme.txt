NOM     : JEAN
PRENOM  : Somara Maillekar
NIVEAU  : Niveau 2
vaction : median
section : sces informatiques
CODE    : 33648